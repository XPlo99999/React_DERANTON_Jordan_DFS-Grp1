import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import '../styles/nav.css';
const NavigationBar = ({ onLogout, isAdmin }) => {
    return (
        <nav className="nav-bar">
            <ul>
                <li><Link to="/home">Accueil</Link></li>
                {isAdmin && <li><Link to="/users">Utilisateurs</Link></li>}
                <li><button onClick={onLogout}>Déconnexion</button></li>
            </ul>
        </nav>
    );
};
NavigationBar.propTypes = {
    onLogout: PropTypes.func.isRequired,
    isAdmin: PropTypes.bool.isRequired,
};
export default NavigationBar;