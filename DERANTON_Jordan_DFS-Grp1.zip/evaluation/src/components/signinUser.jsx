import React, { useState } from 'react';
import axios from 'axios';
import Home from '../pages/home.jsx';
import '../styles/auth.css';
const SIGNIN_API_URL = 'http://localhost:4555/login';
const SignInUser = ({ onSignIn }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const handleSignIn = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post(SIGNIN_API_URL, {
                id: username,
                password: password,
            });
            const token = response.data;
            console.log('Reponse data:', token);
            if (token) {
                localStorage.setItem('token', token);
                setIsLoggedIn(true);
                setError(null);
                onSignIn();
            } else {
                setError("Token non-trouvé.");
            }
        } catch (error) {
            setError(error.response ? error.response.data.error : 'Erreur');
        }
    };
    if (isLoggedIn) {
        return <Home onLogout={() => setIsLoggedIn(false)} />;
    }
    return (
        <div className="signin-form">
            <form onSubmit={handleSignIn}>
                <h2>Connexion</h2>
                <label>
                    Identifiant :
                    <input type="text" className="form-input" value={username} onChange={(event) => setUsername(event.target.value)} />
                </label>
                <label>
                    Mot de passe :
                    <input type="password" className="form-input" value={password} onChange={(event) => setPassword(event.target.value)} />
                </label>
                <button type="submit" className="btn-submit">Se connecter</button>
                {error && <div className="error-message">{error}</div>}
            </form>
        </div>
    );
};
export default SignInUser;