import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/users.css';
import NavigationBar from '../components/navBar.jsx';
const Utilisateurs = ({ onLogout }) => {
    const [isAdmin, setIsAdmin] = useState(false);
    const [users, setUsers] = useState([]);
    const [editingUserId, setEditingUserId] = useState(null);
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const checkAdminStatus = async () => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                console.log('Token pour vérification admin:', token);
                const response = await axios.get('http://localhost:4555/isadmin', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setIsAdmin(response.data.isAdmin);
            }
        } catch (error) {
            console.error('Erreur lors de la vérification des droits d\'administrateur:', error);
        }
    };
    const fetchUsers = async () => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                console.log('Token pour récupération utilisateurs:', token);
                const response = await axios.get('http://localhost:4555/users', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUsers(response.data);
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des utilisateurs:', error);
        }
    };
    const updateUserType = async (userId, newType) => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await axios.patch(
                    `http://localhost:4555/usertype/${userId}`,
                    { newType },
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                console.log('Type d\'utilisateur mis à jour avec succès:', response.data);
                fetchUsers();
            }
        } catch (error) {
            console.error('Erreur lors de la mise à jour du type d\'utilisateur:', error);
            if (error.response) {
                console.error('Données de la réponse d\'erreur:', error.response.data);
                console.error('Code d\'erreur:', error.response.status);
            }
        }
    };
    const changePassword = async (e) => {
        e.preventDefault();
        if (newPassword !== confirmPassword) {
            setError('Les mots de passe ne correspondent pas.');
            return;
        }
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await axios.post(
                    'http://localhost:4555/userpassword',
                    {
                        oldPassword,
                        password: newPassword 
                    },
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                );
                setSuccess('Mot de passe mis à jour avec succès.');
                setError('');
                setEditingUserId(null);
                setOldPassword('');
                setNewPassword('');
                setConfirmPassword('');
            }
        } catch (error) {
            console.error('Erreur lors de la mise à jour du mot de passe:', error);
            setError('Erreur lors de la mise à jour du mot de passe.');
            if (error.response) {
                console.error('Données de la réponse d\'erreur:', error.response.data);
                console.error('Code d\'erreur:', error.response.status);
            }
        }
    };
    useEffect(() => {
        checkAdminStatus();
        fetchUsers();
    }, []);
    return (
        <div>
            <NavigationBar onLogout={onLogout} isAdmin={isAdmin} />
            <div className="container">
                <table className="users-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user, index) => (
                            <tr key={index}>
                                <td>{user.id}</td>
                                <td>{user.type}</td>
                                <td>
                                    <button onClick={() => updateUserType(user.id, user.type === 'admin' ? 'user' : 'admin')}>
                                        Changer l'accès pour : {user.type === 'admin' ? 'user' : 'admin'}
                                    </button>
                                    <button onClick={() => setEditingUserId(user.id)}>
                                        Changer mot de passe
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {editingUserId && (
                    <form onSubmit={changePassword} className="password-form">
                        <h2>Changer le mot de passe</h2>
                        <div>
                            <label htmlFor="oldPassword">Ancien mot de passe</label>
                            <input
                                type="password"
                                id="oldPassword"
                                value={oldPassword}
                                onChange={(e) => setOldPassword(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="newPassword">Nouveau mot de passe</label>
                            <input
                                type="password"
                                id="newPassword"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="confirmPassword">Confirmer le mot de passe</label>
                            <input
                                type="password"
                                id="confirmPassword"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit">Changer le mot de passe</button>
                        {error && <p className="error">{error}</p>}
                        {success && <p className="success">{success}</p>}
                    </form>
                )}
            </div>
        </div>
    );
};
export default Utilisateurs;