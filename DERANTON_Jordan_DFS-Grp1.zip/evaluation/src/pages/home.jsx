import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/home.css';
import NavigationBar from '../components/navBar.jsx';
const Home = ({ onLogout }) => {
    const [isAdmin, setIsAdmin] = useState(false);
    const [conferences, setConferences] = useState([]);
    const [isFormVisible, setIsFormVisible] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        date: '',
        createdAt: '',
        description: '',
        img: '',
        content: '',
        duration: '',
        osMap: {
            addressl1: '',
            addressl2: '',
            postalCode: '',
            city: '',
            coordinates: []
        },
        speakers: [{ firstname: '', lastname: '' }],
        stakeholders: [{ firstname: '', lastname: '', job: '', img: '' }],
        design: {
            mainColor: '',
            secondColor: ''
        }
    });
    const checkAdminStatus = async () => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await axios.get('http://localhost:4555/isadmin', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setIsAdmin(response.data.isAdmin);
            }
        } catch (error) {
            console.error('Erreur lors de la vérification des droits d\'administrateur:', error);
        }
    };
    const fetchConferences = async () => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await axios.get('http://localhost:4555/conferences', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setConferences(response.data);
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des conférences:', error);
        }
    };
    const toggleFormVisibility = () => {
        setIsFormVisible(prev => !prev);
    };
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevData => ({ ...prevData, [name]: value }));
    };
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await axios.post('http://localhost:4555/conference',
                    { conference: formData },
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                console.log('Conférence créée avec succès:', response.data);
                fetchConferences();
                setFormData({
                    title: '',
                    date: '',
                    createdAt: '',
                    description: '',
                    img: '',
                    content: '',
                    duration: '',
                    osMap: {
                        addressl1: '',
                        addressl2: '',
                        postalCode: '',
                        city: '',
                        coordinates: []
                    },
                    speakers: [{ firstname: '', lastname: '' }],
                    stakeholders: [{ firstname: '', lastname: '', job: '', img: '' }],
                    design: {
                        mainColor: '',
                        secondColor: ''
                    }
                });
                toggleFormVisibility();
            }
        } catch (error) {
            console.error('Erreur lors de la création de la conférence:', error);
        }
    };
    useEffect(() => {
        checkAdminStatus();
        fetchConferences();
    }, []);
    return (
        <div>
            <NavigationBar onLogout={onLogout} isAdmin={isAdmin} />
            <div className="container">
                {isAdmin && (
                    <button onClick={toggleFormVisibility} className="toggle-form-button">
                        {isFormVisible ? 'Masquer le formulaire' : 'Afficher le formulaire'}
                    </button>
                )}
                {isFormVisible && (
                    <form onSubmit={handleFormSubmit} className="conference-form">
                        {/* Informations de la conférence */}
                        <div className="form-section">
                            <h2>Informations de la conférence</h2>
                            {/* Titre */}
                            <div className="form-group">
                                <label htmlFor="title">Titre</label>
                                <input
                                    type="text"
                                    id="title"
                                    name="title"
                                    value={formData.title}
                                    onChange={handleInputChange}
                                    placeholder="Entrez le titre de la conférence"
                                    required
                                />
                            </div>
                            {/* Dates */}
                            <div className="form-group">
                                <label htmlFor="date">Date</label>
                                <input
                                    type="date"
                                    id="date"
                                    name="date"
                                    value={formData.date}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="createdAt">Date de Création</label>
                                <input
                                    type="date"
                                    id="createdAt"
                                    name="createdAt"
                                    value={formData.createdAt}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="description">Description</label>
                                <textarea
                                    id="description"
                                    name="description"
                                    value={formData.description}
                                    onChange={handleInputChange}
                                    placeholder="Entrez une description"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="img">Image URL</label>
                                <input
                                    type="text"
                                    id="img"
                                    name="img"
                                    value={formData.img}
                                    onChange={handleInputChange}
                                    placeholder="Entrez l'URL de l'image"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="content">Contenu</label>
                                <textarea
                                    id="content"
                                    name="content"
                                    value={formData.content}
                                    onChange={handleInputChange}
                                    placeholder="Entrez le contenu"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="duration">Durée</label>
                                <input
                                    type="text"
                                    id="duration"
                                    name="duration"
                                    value={formData.duration}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la durée"
                                />
                            </div>
                        </div>
                        {/* Adresse */}
                        <div className="form-section">
                            <h2>Adresse</h2>
                            <div className="form-group">
                                <label htmlFor="osMap.addressl1">Adresse 1</label>
                                <input
                                    type="text"
                                    id="osMap.addressl1"
                                    name="osMap.addressl1"
                                    value={formData.osMap.addressl1}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la première ligne d'adresse"
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="osMap.addressl2">Adresse 2</label>
                                <input
                                    type="text"
                                    id="osMap.addressl2"
                                    name="osMap.addressl2"
                                    value={formData.osMap.addressl2}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la deuxième ligne d'adresse"
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="osMap.postalCode">Code Postal</label>
                                <input
                                    type="text"
                                    id="osMap.postalCode"
                                    name="osMap.postalCode"
                                    value={formData.osMap.postalCode}
                                    onChange={handleInputChange}
                                    placeholder="Entrez le code postal"
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="osMap.city">Ville</label>
                                <input
                                    type="text"
                                    id="osMap.city"
                                    name="osMap.city"
                                    value={formData.osMap.city}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la ville"
                                />
                            </div>
                        </div>
                        {/* Intervenants */}
                        <div className="form-section">
                            <h2>Intervenants</h2>
                            {formData.speakers.map((speaker, index) => (
                                <div key={index} className="form-group">
                                    <label htmlFor={`speakers[${index}].firstname`}>Prénom</label>
                                    <input
                                        type="text"
                                        id={`speakers[${index}].firstname`}
                                        name={`speakers[${index}].firstname`}
                                        value={speaker.firstname}
                                        onChange={(e) => {
                                            const updatedSpeakers = [...formData.speakers];
                                            updatedSpeakers[index].firstname = e.target.value;
                                            setFormData(prevData => ({ ...prevData, speakers: updatedSpeakers }));
                                        }}
                                        placeholder="Entrez le prénom de l'intervenant"
                                    />
                                    <label htmlFor={`speakers[${index}].lastname`}>Nom</label>
                                    <input
                                        type="text"
                                        id={`speakers[${index}].lastname`}
                                        name={`speakers[${index}].lastname`}
                                        value={speaker.lastname}
                                        onChange={(e) => {
                                            const updatedSpeakers = [...formData.speakers];
                                            updatedSpeakers[index].lastname = e.target.value;
                                            setFormData(prevData => ({ ...prevData, speakers: updatedSpeakers }));
                                        }}
                                        placeholder="Entrez le nom de l'intervenant"
                                    />
                                </div>
                            ))}
                        </div>
                        {/* Partenaires */}
                        <div className="form-section">
                            <h2>Partenaires</h2>
                            {formData.stakeholders.map((stakeholder, index) => (
                                <div key={index} className="form-group">
                                    <label htmlFor={`stakeholders[${index}].firstname`}>Prénom</label>
                                    <input
                                        type="text"
                                        id={`stakeholders[${index}].firstname`}
                                        name={`stakeholders[${index}].firstname`}
                                        value={stakeholder.firstname}
                                        onChange={(e) => {
                                            const updatedStakeholders = [...formData.stakeholders];
                                            updatedStakeholders[index].firstname = e.target.value;
                                            setFormData(prevData => ({ ...prevData, stakeholders: updatedStakeholders }));
                                        }}
                                        placeholder="Entrez le prénom du partenaire"
                                    />
                                    <label htmlFor={`stakeholders[${index}].lastname`}>Nom</label>
                                    <input
                                        type="text"
                                        id={`stakeholders[${index}].lastname`}
                                        name={`stakeholders[${index}].lastname`}
                                        value={stakeholder.lastname}
                                        onChange={(e) => {
                                            const updatedStakeholders = [...formData.stakeholders];
                                            updatedStakeholders[index].lastname = e.target.value;
                                            setFormData(prevData => ({ ...prevData, stakeholders: updatedStakeholders }));
                                        }}
                                        placeholder="Entrez le nom du partenaire"
                                    />
                                    <label htmlFor={`stakeholders[${index}].job`}>Poste</label>
                                    <input
                                        type="text"
                                        id={`stakeholders[${index}].job`}
                                        name={`stakeholders[${index}].job`}
                                        value={stakeholder.job}
                                        onChange={(e) => {
                                            const updatedStakeholders = [...formData.stakeholders];
                                            updatedStakeholders[index].job = e.target.value;
                                            setFormData(prevData => ({ ...prevData, stakeholders: updatedStakeholders }));
                                        }}
                                        placeholder="Entrez le poste du partenaire"
                                    />
                                    <label htmlFor={`stakeholders[${index}].img`}>Image URL</label>
                                    <input
                                        type="text"
                                        id={`stakeholders[${index}].img`}
                                        name={`stakeholders[${index}].img`}
                                        value={stakeholder.img}
                                        onChange={(e) => {
                                            const updatedStakeholders = [...formData.stakeholders];
                                            updatedStakeholders[index].img = e.target.value;
                                            setFormData(prevData => ({ ...prevData, stakeholders: updatedStakeholders }));
                                        }}
                                        placeholder="Entrez l'URL de l'image du partenaire"
                                    />
                                </div>
                            ))}
                        </div>
                        {/* Design */}
                        <div className="form-section">
                            <h2>Design</h2>
                            <div className="form-group">
                                <label htmlFor="design.mainColor">Couleur Principale</label>
                                <input
                                    type="text"
                                    id="design.mainColor"
                                    name="design.mainColor"
                                    value={formData.design.mainColor}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la couleur principale"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="design.secondColor">Deuxième Couleur</label>
                                <input
                                    type="text"
                                    id="design.secondColor"
                                    name="design.secondColor"
                                    value={formData.design.secondColor}
                                    onChange={handleInputChange}
                                    placeholder="Entrez la deuxième couleur"
                                    required
                                />
                            </div>
                        </div>
                        <button type="submit">Créer la Conférence</button>
                    </form>
                )}
                <table className="conferences-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Titre</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {conferences.map((conference, index) => (
                            <tr key={index}>
                                <td>{conference.id}</td>
                                <td>{conference.title}</td>
                                <td>{conference.date}</td>
                                <td>
                                    <button onClick={() => alert(`Détails de la conférence ${conference.id}`)}>
                                        Voir Détails
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
export default Home;