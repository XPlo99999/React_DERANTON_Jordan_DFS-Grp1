import React, { useState } from 'react';
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate
} from 'react-router-dom';
import './App.css';
import SignInUser from './components/signinUser.jsx';
import SignUpUser from './components/signupUser.jsx';
import SignUpAdminUser from './components/signupAdminUser.jsx';
import Home from './pages/home.jsx';
import Users from './pages/users.jsx';
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));
  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
  };
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/home" element={isLoggedIn ? (
            <Home onLogout={handleLogout} />
          ) : (
            <Navigate to="/" />
          )} />
          <Route path="/users" element={isLoggedIn ? (
            <Users onLogout={handleLogout} />
          ) : (
            <Navigate to="/" />
          )} />
          <Route path="/" element={!isLoggedIn ? (
            <div>
              <div className="signup-flex">
                <SignUpAdminUser />
                <SignUpUser />
              </div>
              <div className="signin-flex">
                <SignInUser onSignIn={() => setIsLoggedIn(true)} />
              </div>
            </div>
          ) : (
            <Navigate to="/home" />
          )} />
        </Routes>
      </div>
    </Router>
  );
};
export default App;